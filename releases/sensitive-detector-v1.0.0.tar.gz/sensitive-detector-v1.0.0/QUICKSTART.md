# 快速开始指南

## 一键安装

```bash
# 1. 解压部署包
tar -xzf sensitive-detector-v*.tar.gz
cd sensitive-detector-v*

# 2. 执行安装
chmod +x install.sh
./install.sh

# 3. 访问系统
# 浏览器打开: http://localhost:8000
```

## Gitee 部署（推荐）

```bash
# 1. 下载 Gitee 部署脚本
wget https://gitee.com/saisai5203/sensitive-detector/raw/main/scripts/gitee-deploy.sh

# 2. 执行部署
chmod +x gitee-deploy.sh
./gitee-deploy.sh

# 3. 访问系统
# 浏览器打开: http://localhost:8000
```

## 手动安装

```bash
# 1. 启动 Ollama 服务
curl -fsSL https://ollama.ai/install.sh | sh
ollama serve &
ollama pull qwen:7b

# 2. 启动应用
docker compose up -d

# 3. 访问系统
# 浏览器打开: http://localhost:8000
```

## 管理命令

```bash
# 查看日志
docker compose logs -f

# 停止服务
docker compose down

# 重启服务
docker compose restart

# 查看状态
docker compose ps
```

## 故障排除

如果遇到问题，请查看：
- [故障排除文档](docs/TROUBLESHOOTING.md)
- [API 文档](docs/API.md)
- [Docker 部署指南](docs/DOCKER_DEPLOYMENT.md)
- [Gitee 部署指南](docs/GITEE_DEPLOYMENT.md)
