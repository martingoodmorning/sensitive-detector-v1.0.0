# 变更日志

## v1.0.0 (2024-01-01)

### 新增功能
- 文本敏感词检测
- 文档敏感词检测 (TXT, PDF, DOCX)
- 规则匹配 + LLM 双重检测
- Web 界面
- Docker 容器化部署

### 技术特性
- FastAPI 后端
- Ollama LLM 集成
- 响应式前端界面
- 健康检查
- 日志记录

### 支持格式
- 文本输入
- TXT 文件
- PDF 文件
- DOCX 文件

### 系统要求
- Docker 20.10+
- Docker Compose 2.0+
- 8GB+ 内存
- 20GB+ 磁盘空间
